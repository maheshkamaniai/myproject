<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <!-- <div id="app"> -->
    <!-- <main class="py-4"> -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- </main> -->
    <!-- </div> -->
</body>
<?php echo $__env->make('layouts.footar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</html>