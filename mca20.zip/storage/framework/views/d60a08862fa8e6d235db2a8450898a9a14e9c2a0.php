<?php $__env->startSection('content'); ?>
<?php $page='Dashboard'?>
<div id="main_content">
    <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="page">
            <?php echo $__env->make('layouts.tophead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="section-body mt-3">
            <div class="container-fluid">
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="mb-4">
                            <h4>Welcome To Awesome Infosys</h4>
                        </div>
                    </div>
                </div>
                <div class="row clearfix row-deck">
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">OnGoing Project</h3>
                            </div>
                            <div class="card-body">
                                <h5 class="number mb-0 font-32 counter"><?php echo $OnGoingdata; ?></h5>
                                <span class="font-12"><a href="<?php echo e(url('Project-List/ongoing')); ?>">More</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Upcomming Project</h3>
                            </div>
                            <div class="card-body">
                                <h5 class="number mb-0 font-32 counter"><?php echo $Upcommingdata; ?></h5>
                                <span class="font-12"><a href="<?php echo e(url('Project-List/upcomming')); ?>">More</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Closed Project</h3>
                            </div>
                            <div class="card-body">
                                <h5 class="number mb-0 font-32 counter"><?php echo $Closeddata; ?></h5>
                                <span class="font-12"> <a href="<?php echo e(url('Project-List/closed')); ?>">More</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Team Members</h3>
                            </div>
                            <div class="card-body">
                                <h5 class="number mb-0 font-32 counter"><?php echo $teammembers; ?></h5>
                                <span class="font-12"><a href="<?php echo e(url('Team-Member')); ?>">More</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section-body">
            <div class="container-fluid">

                <div class="row clearfix">
                    <div class="col-12 col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Project Summary</h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover table-striped text-nowrap table-vcenter mb-0">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Client Name</th>
                                                <th>Team</th>
                                                <th>Project</th>

                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $c = 0;
                                            foreach ($Summary as $post) {
                                                $c++;
                                                $teammember = DB::table('tbl_teammember')->whereIn('id', explode(",", $post->team_member_id))->select('img')->get();
                                            ?>
                                                <tr>
                                                    <td><?= $c ?></td>
                                                    <td><?= $post->company_name ?></td>
                                                    <td>
                                                        <ul class="list-unstyled team-info sm margin-0 w150">
                                                            <?php
                                                            if ($teammember != '') {
                                                                foreach ($teammember as $team) {
                                                            ?>
                                                                    <li><img src="<?php echo e(URL::asset('pimage/'.$team->img)); ?>" alt="Avatar">
                                                                    </li>
                                                            <?php
                                                                }
                                                            }
                                                            ?>
                                                        </ul>
                                                    </td>
                                                    <td><?= $post->project_title ?></td>

                                                    <td>
                                                        <?php
                                                        if ($post->project_status == 1) {
                                                            echo " <span class='tag tag-primary'>In Progress </span>";
                                                        } elseif ($post->project_status == 2) {
                                                            echo "<span class='tag tag-orange'>  Panding  </span>";
                                                        } elseif ($post->project_status == 3) {
                                                            echo "<span class='tag tag-success'> Closed </span>";
                                                        } else {
                                                            echo "Have a good night!";
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- <?php //include('includes/footer.php'); 
                ?>
        </div>
    </div>


    <?php //include('includes/footerjs.php'); 
    ?>
</body>

 soccer/project/  07 Jan 2020 03:37:22 GMT 

</html> -->
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>