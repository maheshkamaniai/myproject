<!-- <script src="<?php echo e(asset('assets/js/app.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/bundles/lib.vendor.bundle.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('assets/bundles/apexcharts.bundle.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/bundles/counterup.bundle.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/bundles/knobjs.bundle.js')); ?>" defer></script> -->
<!-- <script src="<?php echo e(asset('assets/bundles/c3.bundle.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/js/page/project-index.js')); ?>" defer></script> -->
<script src="<?php echo e(asset('assets/bundles/lib.vendor.bundle.js')); ?>" defer></script>

<script src="<?php echo e(asset('assets/js/core.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/plugins/dropify/js/dropify.min.js')); ?>" defer></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.jquery.min.js"></script>


<script src="<?php echo e(asset('assets/js/form/dropify.js')); ?>" defer></script>


