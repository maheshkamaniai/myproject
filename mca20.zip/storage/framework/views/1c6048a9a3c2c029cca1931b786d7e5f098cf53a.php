<?php $__env->startSection('content'); ?>
<?php
$button = 'Add';
$title = '';
$sdate = '';
$edate = '';
if ($id != '') {
    $title = $taskdata->title;
    $sdate = $taskdata->sdate;
    $edate = $taskdata->edate;
    $button = 'Update';
}

?>
<div id="main_content">
    <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="page">
    <?php echo $__env->make('layouts.tophead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="section-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="d-flex justify-content-between align-items-center">
                            <ul class="nav nav-tabs page-header-tab">
                                <li class="nav-item"><a class="nav-link" href=""><i class="fa fa-list"></i> Module</a></li>
                                <li class="nav-item"><a class="nav-link active" id="" data-toggle="tab" href="tasklist.php"><i class="fa fa-plus"></i> Add Task</a></li>
                            </ul>
                            <div class="header-action d-md-flex">
                                <div class="input-group mr-2">
                                    <input type="text" class="form-control" placeholder="Search...">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section-body mt-3">
            <div class="container-fluid">
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <form action='<?php echo e(url("Project-List/tasklist/insert")); ?>' method='post' enctype='multipart/form-data'>
                                    <div class="row">
                                        <?php echo e(csrf_field()); ?>

                                        <input type='hidden' name='moduleid' value='<?php echo e($moduleid); ?>'>
                                        <input type='hidden' name='id' value='<?php echo e($id); ?>'>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Task Name</label>
                                                <input type="text" name='task_name' value='<?php echo e($title); ?>' class="form-control" placeholder="Task Name">
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Start Date</label>
                                                <input type="date" name='sdate' value='<?php echo e($sdate); ?>' class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>End Date</label>
                                                <input type="date" name='edate' value='<?php echo e($edate); ?>' class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <button type="submit" class="btn btn-primary"><?php echo e($button); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section-body mt-3">
            <div class="container-fluid">
                <div class="tab-content">

                    <div class="tab-pane active" id="addnew" role="tabpanel">
                        <div class="row clearfix">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <table class="table">
                                            <tr class='thead-dark'>
                                                <th>#</th>
                                                <th>Task Name</th>
                                                <th>Start Date</th>
                                                <th>End Date</th>
                                                <th>Action</th>
                                            </tr>
                                            <?php $i = 1; ?>
                                            <?php $__currentLoopData = $tasklist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td><?php echo e($task->title); ?></td>
                                                <td><?php echo e($task->sdate); ?></td>
                                                <td><?php echo e($task->edate); ?></td>
                                                <td>

                                                    <div class=btn-group><a href='<?= url('Project-List/tasklist/' . $moduleid . '/' . $task->id) ?>' class='btn btn-info btn-xs'><span class='fa fa-pencil'></span></a>
                                                    </div>
                                                    <div class=btn-group><a class="btn btn-danger btn-flat btn-xs remove-user" data-id="<?php echo e($task->id); ?>" data-action="#" onclick="deleteConfirmation(<?php echo e($task->id); ?>)"> <span class='fa fa-trash'></span></a></span></a>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="section-body">
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <a href="templateshub.net">Templates Hub</a>
                        </div>
                        <div class="col-md-6 col-sm-12 text-md-right">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item"><a href="doc/index.php">Documentation</a></li>
                                <li class="list-inline-item"><a href="javascript:void(0)">FAQ</a></li>
                                <li class="list-inline-item"><a href="javascript:void(0)" class="btn btn-outline-primary btn-icon">Buy Now</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.all.min.js"></script>

<script type="text/javascript">
    function deleteConfirmation(id) {
        swal({
            title: "Delete?",
            text: "Please ensure and then confirm!",
            type: "warning",
            showCancelButton: !0,
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel!",
            reverseButtons: !0
        }).then(function(e) {

            if (e.value === true) {
                var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

                window.location.href = "<?php echo e(url('Project-List/deleteTask/')); ?>/" + id

            } else {
                swal({
                    title: "Cancelled",
                    text: "Your Records are safe :)",
                    type: "error",
                    confirmButtonClass: "btn-danger"
                });
            }

        }, function(dismiss) {
            return false;
        })
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>