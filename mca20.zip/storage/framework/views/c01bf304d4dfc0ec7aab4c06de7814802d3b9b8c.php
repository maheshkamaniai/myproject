<?php $__env->startSection('content'); ?>
<?php $page='Taskboard'; ?>
        <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="page">
            <?php echo $__env->make('layouts.tophead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="section-body mt-3">
                <div class="container-fluid">
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="list" role="tabpanel">
                            <div class='row col-md-12' style='margin-top:10px'>                                                                    
                            <?php // print_r($Taskboard);
                            foreach ($Taskboard as $post) { ?>
                            <div class="col-md-4">
                                <div class="card">
                                    <a href="<?php echo e(URL('Taskboard/addmodule/'. $post->id)); ?>">
                                        <div class="card-body text-center ribbon">
                                            <img class="rounded-circle img-thumbnail w100" style='width: 90px;
                                            height: 86px;' src="../upload/<?php echo e($post->project_logo); ?>" alt="">
                                            <h6 class="mt-3 mb-0"><?php echo e($post->project_title); ?></h6>
                                        
                                        </div>
                                    </a>
                                </div>
                            </div>

                            <?php } ?>
                        </div>
                        </div>
                     
                    </div>
                </div>
            </div>
        </div>


    <div class="section-body">
        <?php echo $__env->make('layouts.footar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>


    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>