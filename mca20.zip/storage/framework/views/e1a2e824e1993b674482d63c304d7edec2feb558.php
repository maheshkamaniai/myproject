<?php $__env->startSection('content'); ?>
<body class="font-montserrat">
    <div class="auth">
        <div class="auth_left">
            <div class="card">
                <div class="text-center mb-5">
                    <a class="header-brand" href="index-2.html"><i class="fa fa-soccer-ball-o brand-logo"></i></a>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-title">Create new account</div>
                        <div class="form-group">
                            <label class="form-label">Name</label>

                            <input id="name" type="text"
                                class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name"
                                value="<?php echo e(old('name')); ?>" required autofocus>
                            <?php if($errors->has('name')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email address</label>
                            <input id="email" type="email"
                                class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email"
                                value="<?php echo e(old('email')); ?>" required>

                            <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Password</label>
                            <input id="password" type="password"
                                class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password"
                                required>

                            <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="form-label"><?php echo e(__('Confirm Password')); ?></label>
                            <input id="password-confirm" type="password" class="form-control"
                                name="password_confirmation" required>
                        </div>


                        <div class="form-group">
                            <label for="password-confirm" class="form-label"><?php echo e(__('Profile')); ?></label>
                            <input type="file" name="profile" class="form-control">
                        </div>

                        <div class="form-group">
                            <?php $val_Roal=""; ?>
                            <label for="password-confirm" class="form-label">Role </label>
                            <select class="form-control show-tick" name="roal">
                                <option value="">-- Roal --</option>
                                <option value="0" <?php if($val_Roal==1): ?> selected <?php endif; ?>>Admin</option>
                                <option value="1" <?php if($val_Roal==0): ?> selected <?php endif; ?>>Developer</option>
                            </select>

                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                </div>
                </form>
                <div class="text-center text-muted">
                    Already have account? <a href="<?php echo e(route('login')); ?>">Sign in</a>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>