<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="dns-prefetch" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
<link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>
<title>Awesome Infosys</title>
<link rel="shortcut icon" href="{{ asset('assets/favicon.png') }}">
<link rel="stylesheet" href="{{asset('assets/plugins/bootstrap/css/bootstrap.min.css') }}" />
<link rel="stylesheet" href="{{asset('assets/plugins/charts-c3/c3.min.css') }}" />
<link rel="stylesheet" href="{{asset('assets/css/main.css') }}" />
<link rel="stylesheet" href="{{asset('assets/css/theme1.css') }}" />
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
    type="text/css">
    
    <style>
        .btn-xs {
            padding: .25rem .4rem !important;
            font-size: .875rem !important;
            line-height: .5 !important;
            border-radius: .2rem !important;
        }
    </style>
<!-- <link rel="stylesheet" href="{{ asset('css/app.css') }}"> -->